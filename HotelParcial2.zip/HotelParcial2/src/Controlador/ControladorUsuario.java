
package Controlador;
import Modelo.Usuarios;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;


public class ControladorUsuario implements ActionListener {
    
    public boolean registrarUsuarioControlador(String TipoIdentificacion, String NumIdentificacion, String Nombres, String Apellidos, String CorreoElectronico, String Direccion, String Telefono, String Contrasena, String Ciudad) {
    
    // Comprueba que no haya campos vacíos o nulos
    if (TipoIdentificacion == null || TipoIdentificacion.isBlank() || 
        NumIdentificacion == null || NumIdentificacion.isBlank() || 
        Nombres == null || Nombres.isBlank() || 
        Apellidos == null || Apellidos.isBlank() || 
        CorreoElectronico == null || CorreoElectronico.isBlank() || 
        Direccion == null || Direccion.isBlank() || 
        Telefono == null || Telefono.isBlank() || 
        Contrasena == null || Contrasena.isBlank() || 
        Ciudad == null || Ciudad.isBlank()) 
    {
        
        JOptionPane.showMessageDialog(null, "No se aceptan campos vacíos", "ERROR", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    Usuarios nuevoUsuario = new Usuarios();
    
    // Copiar los datos del usuario en el nuevo objeto
    nuevoUsuario.setTipoIdentificacion(TipoIdentificacion);
    nuevoUsuario.setDocumentoIdentificacion(NumIdentificacion);
    nuevoUsuario.setNombre(Nombres);
    nuevoUsuario.setApellido(Apellidos);
    nuevoUsuario.setCorreoElectronico(CorreoElectronico);
    nuevoUsuario.setDireccionResidencia(Direccion);
    nuevoUsuario.setTelefono(Telefono);
    nuevoUsuario.setCont(Contrasena);
    nuevoUsuario.setCiudadResidencia(Ciudad);
    
    // Guarda el nuevo usuario
    if (nuevoUsuario.registrarUsuario(nuevoUsuario)){
        System.out.println("Usuario guardado correctamente");
        nuevoUsuario.mostrar();
        return true;
    } else {
        System.out.println("Error al guardar usuario");
        return false;
    }
}

    
    public boolean[] iniciarSesionControlador(String CorreoElectronico, String Contrasena){
        if (CorreoElectronico == null || CorreoElectronico.isBlank() || 
            Contrasena == null || Contrasena.isBlank()) 
    {
        boolean[] resultados = new boolean[2];
        resultados[0] = false;
        resultados[1] = false;
        return resultados;
    }
        
        return Usuarios.iniciarSesionUsuario(CorreoElectronico, Contrasena);
    }
    
    public static boolean llamadoLista(){
        return Usuarios.estadoLista();
    }
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
