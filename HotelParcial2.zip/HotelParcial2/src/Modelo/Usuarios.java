package Modelo;

import java.util.ArrayList;
import java.util.List;

public class Usuarios {

    //Constructor por defecto
    public Usuarios(){
    }
    
    private String tipoIdentificacion;
    private String documentoIdentificacion;
    private String nombre;
    private String apellido;
    private String correoElectronico;
    private String direccionResidencia;
    private String ciudadResidencia;
    private String telefono;
    private String cont;

    public String getCont() {
        return cont;
    }

    public void setCont(String cont) {
        this.cont = cont;
    }

    public String getTipoIdentificacion() {
        return tipoIdentificacion;
    }

    public void setTipoIdentificacion(String tipoIdentificacion) {
        this.tipoIdentificacion = tipoIdentificacion;
    }

    public String getDocumentoIdentificacion() {
        return documentoIdentificacion;
    }

    public void setDocumentoIdentificacion(String documentoIdentificacion) {
        this.documentoIdentificacion = documentoIdentificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getDireccionResidencia() {
        return direccionResidencia;
    }

    public void setDireccionResidencia(String direccionResidencia) {
        this.direccionResidencia = direccionResidencia;
    }

    public String getCiudadResidencia() {
        return ciudadResidencia;
    }

    public void setCiudadResidencia(String ciudadResidencia) {
        this.ciudadResidencia = ciudadResidencia;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
    
    //IMPORTANTE
    //Lista que guardará los arrays de datos de los usuarios
    
    static List<Usuarios> registro_usuarios = new ArrayList<>(); //Declaración Global
    
    
    //Guarda los datos del usuario organizados en el controlador
    
    public boolean registrarUsuario(Usuarios nuevoUsuario){
    
    boolean confirmacion;    
    confirmacion = registro_usuarios.add(nuevoUsuario);
    
    return confirmacion;
    }

    
    //Mostrar en consola los usuarios registrados

    public void mostrar() {
    for (Usuarios usuario : registro_usuarios) {
        System.out.println("Tipo de Identificacion: " + usuario.getTipoIdentificacion());
        System.out.println("Numero de Identificacion: " + usuario.getDocumentoIdentificacion());
        System.out.println("Nombres: " + usuario.getNombre());
        System.out.println("Apellidos: " + usuario.getApellido());
        System.out.println("Correo Electronico: " + usuario.getCorreoElectronico());
        System.out.println("Direccion de Residencia: " + usuario.getDireccionResidencia());
        System.out.println("Ciudad de Residencia: " + usuario.getCiudadResidencia());
        System.out.println("Telefono: " + usuario.getTelefono());
        System.out.println("Contrasena: " + usuario.getCont());
        System.out.println("-----------------------");
        }
    }

    
    //Por el modo de acceso de la lista de Usuarios privado, es prudente crearlo como método de Usuarios
    public static boolean[] iniciarSesionUsuario(String CorreoElectronico, String Contrasena) {
        
    boolean[] resultados = new boolean[2];
        
    // Recorrido de la lista de usuarios
    for (Usuarios usuario : registro_usuarios) {

        // Verificar si las credenciales coinciden con las del usuario actual
        if (CorreoElectronico.equals(usuario.getCorreoElectronico()) && Contrasena.equals(usuario.getCont())) {
            
            if(usuario instanceof Administrador && ((Administrador) usuario).isUsuarioAdministrador()){
               // Si coinciden y se trata de un administrador, devolver verdadero y salir del método
                resultados[0] = true;
                resultados[1] = true;
                return resultados; 
            }else{
                // Si no coinciden, entonces es un cliente
            resultados[0] = true;
            resultados[1] = false;
            return resultados;
            }

            }
        }
    
    // Si se recorre toda la lista de usuarios y no se encuentra una coincidencia, devolver falso
    resultados[0] = false;
    resultados[1] = false;
    return resultados;
    }
    
    public static boolean estadoLista(){
        return registro_usuarios.isEmpty();
    }
    
}
