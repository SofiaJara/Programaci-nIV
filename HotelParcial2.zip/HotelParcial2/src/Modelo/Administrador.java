package Modelo;


public class Administrador extends Usuarios{
    
    //Se crea un usuario al cual se le añade que contenga el booleano true
    
    private boolean usuarioAdministrador = true;

    public Administrador() {
    }

    public boolean isUsuarioAdministrador() {
        return usuarioAdministrador;
    }

    public void setUsuarioAdministrador(boolean usuarioAdministrador) {
        this.usuarioAdministrador = usuarioAdministrador;
    }
  
}
