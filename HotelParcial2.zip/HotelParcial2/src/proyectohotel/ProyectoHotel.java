package proyectohotel;
import Vista.*;
import Modelo.*;
import javax.swing.JFrame;

public class ProyectoHotel {
 
    public static void main(String[] args) {
        
        //Se crea inicialmente el usuario de administrador 
        Administrador admin = new Administrador();
        
        admin.setTipoIdentificacion("Cedula");
        admin.setDocumentoIdentificacion("1088244726");
        admin.setNombre("Sofia");
        admin.setApellido("Jaramillo");
        admin.setCorreoElectronico("sofia.jaramillo1@utp.edu.co");
        admin.setCont("sofia");
        admin.setCiudadResidencia("Dosquebradas");
        admin.setDireccionResidencia("Unico");
        admin.setTelefono("3129784576");
        admin.setUsuarioAdministrador(true);
        
        //Considerando que no se llama al controlador para ingresar este usuario, se hará manualmente
        Usuarios ingresoU = new Usuarios();
        
        if(ingresoU.registrarUsuario(admin)){
            System.out.println("Vista Administrador seleccionable");
        }else{
            System.out.println("El Administrador no fue registrado Correctamente");
        }
        
        VentanaPrincipal ventana = new VentanaPrincipal();
        
        ventana.setSize(400, 300);
        ventana.setLocationRelativeTo(null);
        // Configurar la operación por defecto al cerrar la ventana
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Hacer visible la ventana
        ventana.setVisible(true);
        
    }
    
}
