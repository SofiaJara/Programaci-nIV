package Modelo;

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

public class Habitacion {
    
    private String idHabitacion;
    private int capacidadDeAlojo; //La capacidad de alojo debe ser de 1 entre 6 huéspedes
    private boolean disponible; 
    private float precioPorNoche;
    private String descripcion;
    
    //Aquí se genera la lista de reservas
    private List<Reserva> registro_reservas;

    public Habitacion(){
        registro_reservas = new ArrayList();
    }
    
    
    public boolean agregarReserva(Reserva nuevaReserva){
        return registro_reservas.add(nuevaReserva);    
    }
    
    public boolean eliminarReserva(Reserva viejaReserva){
        return registro_reservas.remove(viejaReserva);
    }
    
    public List<Reserva> getReservas(){
        return registro_reservas;
    }
    
    public boolean IsReservada(String idHabitacion, LocalDate fechaEntrada, LocalDate fechaSalida){
        if(!registro_reservas.isEmpty()){
           for(Reserva cadaReserva :registro_reservas){
               
               //Los siguientes son los cuatros casos posibles en que las fechas coincidan
            if(cadaReserva.getIdHabitacion().equals(idHabitacion) && "Activo".equals(cadaReserva.isEstadoReserva())){
                if((fechaEntrada.isBefore(cadaReserva.getFechaEntrada()) && fechaSalida.isBefore(cadaReserva.getFechaSalida()))
                        ||
                        (fechaEntrada.isBefore(cadaReserva.getFechaEntrada()) && fechaSalida.isAfter(cadaReserva.getFechaSalida()))
                        ||
                        (fechaEntrada.isAfter(cadaReserva.getFechaEntrada()) && fechaSalida.isBefore(cadaReserva.getFechaSalida()))
                        ||
                        (fechaEntrada.isAfter(cadaReserva.getFechaEntrada()) && fechaEntrada.isBefore(cadaReserva.getFechaSalida()))
                        ||
                        (fechaEntrada.isEqual(cadaReserva.getFechaEntrada()) && fechaSalida.isEqual(cadaReserva.getFechaSalida()))
                        ){
                    return false;
                }
            }
        } 
        }
        return true;
        
    }
    
    //IMPORTANTE
    //Lista que guardará los arrays de datos de las habitaciones disponibles
    
    private static List<Habitacion> registro_habitaciones = new ArrayList<>(); 

    
    public Habitacion(String idHabitacion, int capacidadDeAlojo, boolean disponible, float precioPorNoche, String descripcion) {
        this.idHabitacion = idHabitacion;
        this.capacidadDeAlojo = capacidadDeAlojo;
        this.disponible = disponible;
        this.precioPorNoche = precioPorNoche;
        this.descripcion = descripcion;
        registro_reservas = new ArrayList();
    }
    
    public String getIdHabitacion() {
        return idHabitacion;
    }

    public void setIdHabitacion(String idHabitacion) {
        this.idHabitacion = idHabitacion;
    }

    public int getCapacidadDeAlojo() {
        return capacidadDeAlojo;
    }

    public void setCapacidadDeAlojo(int capacidadDeAlojo) {
        this.capacidadDeAlojo = capacidadDeAlojo;
    }

    public boolean isDisponible() {
        return disponible;
    }

    public void setDisponible(boolean disponible) {
        this.disponible = disponible;
    }

    public float getPrecioPorNoche() {
        return precioPorNoche;
    }

    public void setPrecioPorNoche(float precioPorNoche) {
        this.precioPorNoche = precioPorNoche;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    //Para mostrar las habitaciones del sistema  
    public static List<Habitacion> getRegistro_habitaciones() {
        return new ArrayList<>(registro_habitaciones);
    }

    public String detallesHabitacion() {
        return " Habitacion \n Número = " + idHabitacion + "\n Capacidad De Alojo = " + capacidadDeAlojo + "\n Disponible = " + "\n Precio Por Noche = " + precioPorNoche + "\n Descripcion = " + descripcion;
    }
    
    public String detallesHabitacionAdmin() {
        
    return "<html>Habitación<br> Número : " + idHabitacion + 
           "<br> Capacidad De Alojo : " + capacidadDeAlojo + 
           "<br> Disponible : " + disponible + 
           "<br> Precio Por Noche : " + precioPorNoche + 
           "<br> Descripción : " + descripcion + "</html>";
}

    @Override
    public String toString() {
        return "        Habitacion  :      " + idHabitacion + "               " + precioPorNoche;
    }
    
    
    
    
    
    //ACCIÓN SOLO PARA ADMINISTRADOR ------------------------------------------------------------
    
    //Guardar y eliminar las habitaciones del sistema
    
    public boolean registrarHabitacion(Habitacion nuevaHabitacion){
    
      for(Habitacion cadaHabitacion : registro_habitaciones){
            if(nuevaHabitacion.getIdHabitacion().equals(cadaHabitacion.getIdHabitacion())){
                System.out.print("\n Los Id de las habitaciones no pueden repetirse");
                return false;
            }     
            }   
      
    if((nuevaHabitacion.getCapacidadDeAlojo() % 2) != 0){
        System.out.print("\n Solo se aceptan números pares considerando que todas las camas y camarotes son dobles");
    }
      
    return registro_habitaciones.add(nuevaHabitacion);
    }
    
    
    public boolean eliminarHabitacion (Habitacion viejaHabitacion){
        for(Reserva cadaReserva: registro_reservas){
            if(cadaReserva.getIdHabitacion().equals(viejaHabitacion.getIdHabitacion())){
                viejaHabitacion.eliminarReserva(cadaReserva);
                System.out.print("\n Esta habitación contaba con una reserva");
            }
        }
        return registro_habitaciones.remove(viejaHabitacion); 
    }
}
