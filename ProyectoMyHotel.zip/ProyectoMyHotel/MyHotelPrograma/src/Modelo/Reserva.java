package Modelo;

import java.time.LocalDate;

public class Reserva {
    private static int contadorR = 1;
    private int codigoReserva;
    private String idTitular;
    private String nombreTitular;
    private String idHabitacion;
    private int numeroDeHuespedes;
    private LocalDate fechaReserva;
    private String estadoReserva;
    private LocalDate fechaEntrada;
    private LocalDate fechaSalida;

    public Reserva() {
        this.codigoReserva = contadorR++;
    }

    
    public Reserva(int codigoReserva, String idTitular, String nombreTitular, String idHabitacion, int numeroDeHuespedes, LocalDate fechaReserva, String estadoReserva, LocalDate fechaEntrada, LocalDate fechaSalida) {
        this.codigoReserva = contadorR++;
        this.idTitular = idTitular;
        this.nombreTitular = nombreTitular;
        this.idHabitacion = idHabitacion;
        this.numeroDeHuespedes = numeroDeHuespedes;
        this.fechaReserva = fechaReserva;
        this.estadoReserva = estadoReserva;
        this.fechaEntrada = fechaEntrada;
        this.fechaSalida = fechaSalida;
    }
    
    

    public String getIdTitular() {
        return idTitular;
    }

    public void setIdTitular(String idTitular) {
        this.idTitular = idTitular;
    }

    public String getIdHabitacion() {
        return idHabitacion;
    }

    public void setIdHabitacion(String idHabitacion) {
        this.idHabitacion = idHabitacion;
    }
    
    public int getCodigoReserva() {
        return codigoReserva;
    }

    public void setCodigoReserva() {
        this.codigoReserva = contadorR++;
    }

    public String getNombreTitular() {
        return nombreTitular;
    }

    public void setNombreTitular(String nombreTitular) {
        this.nombreTitular = nombreTitular;
    }

    public int getNumeroDeHuespedes() {
        return numeroDeHuespedes;
    }

    public void setNumeroDeHuespedes(int numeroDeHuespedes) {
        this.numeroDeHuespedes = numeroDeHuespedes;
    }

    public LocalDate getFechaReserva() {
        return fechaReserva;
    }

    public void setFechaReserva(LocalDate fechaReserva) {
        this.fechaReserva = fechaReserva;
    }

    public String isEstadoReserva() {
        return estadoReserva;
    }

    public void setEstadoReserva(String estadoReserva) {
        this.estadoReserva = estadoReserva;
    }

    public LocalDate getFechaEntrada() {
        return fechaEntrada;
    }

    public void setFechaEntrada(LocalDate fechaEntrada) {
        this.fechaEntrada = fechaEntrada;
    }

    public LocalDate getFechaSalida() {
        return fechaSalida;
    }

    public void setFechaSalida(LocalDate fechaSalida) {
        this.fechaSalida = fechaSalida;
    }

    @Override
    public String toString() {
    return "<html>" +
           "<b>Codigo Reserva:</b> " + codigoReserva + "<br>" +
           "<b>Id del Titular:</b> " + idTitular + "<br>" +
           "<b>Nombre del Titular:</b> " + nombreTitular + "<br>" +
           "<b>Habitacion:</b> " + idHabitacion + "<br>" +
           "<b>Número De Huéspedes:</b> " + numeroDeHuespedes + "<br>" +
           "<b>Fecha de Reserva:</b> " + fechaReserva + "<br>" +
           "<b>Estado de la Reserva:</b> " + estadoReserva + "<br>" +
           "<b>Fecha de Entrada:</b> " + fechaEntrada + "<br>" +
           "<b>Fecha de Salida:</b> " + fechaSalida + 
           "</html>";
} 
}
