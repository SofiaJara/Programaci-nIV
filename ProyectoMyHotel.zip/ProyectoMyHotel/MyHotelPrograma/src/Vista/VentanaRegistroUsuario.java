package Vista;
import Controlador.*;
import java.util.Arrays;

import javax.swing.JOptionPane;

public class VentanaRegistroUsuario extends javax.swing.JFrame {

    private int intentos = 0;
    
    public VentanaRegistroUsuario() {
        initComponents();
        setResizable(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Incoherencia = new javax.swing.JDialog();
        nombres = new javax.swing.JTextField();
        apellidos = new javax.swing.JTextField();
        telefono = new javax.swing.JTextField();
        correoElectronico = new javax.swing.JTextField();
        direccionResidencia = new javax.swing.JTextField();
        ciudadResidencia = new javax.swing.JTextField();
        tipoIdentificacion = new javax.swing.JTextField();
        numeroIdentificacion = new javax.swing.JTextField();
        Cont = new javax.swing.JPasswordField();
        ConfirmacionCont = new javax.swing.JPasswordField();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        salir = new javax.swing.JButton();
        registra = new javax.swing.JButton();

        javax.swing.GroupLayout IncoherenciaLayout = new javax.swing.GroupLayout(Incoherencia.getContentPane());
        Incoherencia.getContentPane().setLayout(IncoherenciaLayout);
        IncoherenciaLayout.setHorizontalGroup(
            IncoherenciaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        IncoherenciaLayout.setVerticalGroup(
            IncoherenciaLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        nombres.setFont(new java.awt.Font("Yu Gothic", 0, 12)); // NOI18N
        nombres.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        getContentPane().add(nombres, new org.netbeans.lib.awtextra.AbsoluteConstraints(363, 105, 150, -1));

        apellidos.setFont(new java.awt.Font("Yu Gothic", 0, 12)); // NOI18N
        apellidos.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        apellidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                apellidosActionPerformed(evt);
            }
        });
        getContentPane().add(apellidos, new org.netbeans.lib.awtextra.AbsoluteConstraints(363, 133, 150, -1));

        telefono.setFont(new java.awt.Font("Yu Gothic", 0, 12)); // NOI18N
        telefono.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        telefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                telefonoActionPerformed(evt);
            }
        });
        getContentPane().add(telefono, new org.netbeans.lib.awtextra.AbsoluteConstraints(363, 245, 150, -1));

        correoElectronico.setFont(new java.awt.Font("Yu Gothic", 0, 12)); // NOI18N
        correoElectronico.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        getContentPane().add(correoElectronico, new org.netbeans.lib.awtextra.AbsoluteConstraints(363, 161, 150, -1));

        direccionResidencia.setFont(new java.awt.Font("Yu Gothic", 0, 12)); // NOI18N
        direccionResidencia.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        getContentPane().add(direccionResidencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(363, 189, 150, -1));

        ciudadResidencia.setFont(new java.awt.Font("Yu Gothic", 0, 12)); // NOI18N
        ciudadResidencia.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        ciudadResidencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ciudadResidenciaActionPerformed(evt);
            }
        });
        getContentPane().add(ciudadResidencia, new org.netbeans.lib.awtextra.AbsoluteConstraints(363, 217, 150, -1));

        tipoIdentificacion.setFont(new java.awt.Font("Yu Gothic", 0, 12)); // NOI18N
        tipoIdentificacion.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        getContentPane().add(tipoIdentificacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(363, 49, 150, -1));

        numeroIdentificacion.setFont(new java.awt.Font("Yu Gothic", 0, 12)); // NOI18N
        numeroIdentificacion.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        getContentPane().add(numeroIdentificacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(363, 77, 150, -1));

        Cont.setFont(new java.awt.Font("Yu Gothic", 0, 12)); // NOI18N
        Cont.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        Cont.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ContActionPerformed(evt);
            }
        });
        getContentPane().add(Cont, new org.netbeans.lib.awtextra.AbsoluteConstraints(363, 273, 150, -1));

        ConfirmacionCont.setFont(new java.awt.Font("Yu Gothic", 0, 12)); // NOI18N
        ConfirmacionCont.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        getContentPane().add(ConfirmacionCont, new org.netbeans.lib.awtextra.AbsoluteConstraints(363, 301, 150, -1));

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Formulario De Registro");

        jLabel11.setFont(new java.awt.Font("Yu Gothic", 0, 14)); // NOI18N
        jLabel11.setText("Tipo de Identificación");

        jLabel2.setFont(new java.awt.Font("Yu Gothic", 0, 14)); // NOI18N
        jLabel2.setText("Numero Identificación: ");

        jLabel3.setFont(new java.awt.Font("Yu Gothic", 0, 14)); // NOI18N
        jLabel3.setText("Nombres:");

        jLabel4.setFont(new java.awt.Font("Yu Gothic", 0, 14)); // NOI18N
        jLabel4.setText("Apellidos:");

        jLabel5.setFont(new java.awt.Font("Yu Gothic", 0, 14)); // NOI18N
        jLabel5.setText("Correo Electrónico:");

        jLabel6.setFont(new java.awt.Font("Yu Gothic", 0, 14)); // NOI18N
        jLabel6.setText("Dirección de Residencia:");

        jLabel7.setFont(new java.awt.Font("Yu Gothic", 0, 14)); // NOI18N
        jLabel7.setText("Ciudad de Residencia:");

        jLabel8.setFont(new java.awt.Font("Yu Gothic", 0, 14)); // NOI18N
        jLabel8.setText("Teléfono de Contacto:");

        jLabel9.setFont(new java.awt.Font("Yu Gothic", 0, 14)); // NOI18N
        jLabel9.setText("Contraseña:");

        jLabel10.setFont(new java.awt.Font("Yu Gothic", 0, 14)); // NOI18N
        jLabel10.setText("Confirmación de Contraseña:");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(22, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 201, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 129, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(19, 19, 19))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel11)
                .addGap(2, 2, 2)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addGap(4, 4, 4)
                .addComponent(jLabel4)
                .addGap(8, 8, 8)
                .addComponent(jLabel5)
                .addGap(4, 4, 4)
                .addComponent(jLabel6)
                .addGap(4, 4, 4)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel8))
                    .addComponent(jLabel7))
                .addGap(4, 4, 4)
                .addComponent(jLabel9)
                .addGap(4, 4, 4)
                .addComponent(jLabel10)
                .addContainerGap(37, Short.MAX_VALUE))
        );

        salir.setFont(new java.awt.Font("Yu Gothic", 1, 14)); // NOI18N
        salir.setText("Salir");
        salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirActionPerformed(evt);
            }
        });

        registra.setFont(new java.awt.Font("Yu Gothic", 1, 14)); // NOI18N
        registra.setText("Registrar");
        registra.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registraActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(registra, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 70, Short.MAX_VALUE)
                .addComponent(salir)
                .addGap(50, 50, 50))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(salir)
                    .addComponent(registra))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, 360));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void apellidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_apellidosActionPerformed

    }//GEN-LAST:event_apellidosActionPerformed

    private void registraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registraActionPerformed
        
        //Obtiene el texto ingresado por el usuario
        String TipoIdentificacion = tipoIdentificacion.getText();

        String NumIndentificacion = numeroIdentificacion.getText(); 
        String Nombre = nombres.getText(); 
        String Apellidos = apellidos.getText();
        String CorreoElectronico = correoElectronico.getText();
        String Direccion = direccionResidencia.getText();
        String Ciudad = ciudadResidencia.getText();
        String Telefono  = telefono.getText();
        char[] contra = Cont.getPassword();
        char[] confirmacontra = ConfirmacionCont.getPassword();
        
        //Inicializa una varible booleana para comprobar si las contraseñas coinciden
        boolean bool = Arrays.equals(contra, confirmacontra);
        
        if(intentos < 2){
            if(!bool){
            VentanaEmergente.mostrarVentanaEmergente("Las contraseñas no coinciden", "Incoherencia", JOptionPane.INFORMATION_MESSAGE, 2000);
            }else{
            String Contrasena = String.valueOf(contra);

            ControladorUsuario controla = new ControladorUsuario();
           if(controla.registrarUsuarioControlador(TipoIdentificacion, NumIndentificacion, Nombre, Apellidos, CorreoElectronico, Direccion, Telefono, Contrasena, Ciudad)){
               VentanaEmergente.mostrarVentanaEmergente("Usuario registrado satisfactoriamente", "Éxito", JOptionPane.INFORMATION_MESSAGE, 4000);
               ConfirmacionCont.setText("");
                Cont.setText("");
                apellidos.setText("");
                ciudadResidencia.setText("");
                correoElectronico.setText("");
                direccionResidencia.setText("");
                nombres.setText("");
                numeroIdentificacion.setText("");
                telefono.setText("");
                tipoIdentificacion.setText("");
           }else{
               VentanaEmergente.mostrarVentanaEmergente("El usuario no pudo ser registrado", "Error", JOptionPane.INFORMATION_MESSAGE, 4000);
               dispose();
           }
            }
        Cont.setText("");
        ConfirmacionCont.setText("");
        intentos++;
        }else{
            VentanaEmergente.mostrarVentanaEmergente("Ha excedido el número de intentos", "Acceso Denegado", JOptionPane.INFORMATION_MESSAGE, 3000);   
            dispose();
        }
    }//GEN-LAST:event_registraActionPerformed

    private void telefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_telefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_telefonoActionPerformed

    private void salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirActionPerformed
        dispose();
    }//GEN-LAST:event_salirActionPerformed

    private void ciudadResidenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ciudadResidenciaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ciudadResidenciaActionPerformed

    private void ContActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ContActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ContActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField ConfirmacionCont;
    private javax.swing.JPasswordField Cont;
    private javax.swing.JDialog Incoherencia;
    public javax.swing.JTextField apellidos;
    public javax.swing.JTextField ciudadResidencia;
    public javax.swing.JTextField correoElectronico;
    public javax.swing.JTextField direccionResidencia;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    public javax.swing.JLabel jLabel11;
    public javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    public javax.swing.JTextField nombres;
    public javax.swing.JTextField numeroIdentificacion;
    public javax.swing.JButton registra;
    private javax.swing.JButton salir;
    public javax.swing.JTextField telefono;
    public javax.swing.JTextField tipoIdentificacion;
    // End of variables declaration//GEN-END:variables
}
