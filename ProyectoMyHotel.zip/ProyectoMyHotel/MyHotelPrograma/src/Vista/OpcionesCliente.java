package Vista;

import Modelo.Usuario;
import java.util.List;

public class OpcionesCliente extends javax.swing.JFrame {

    private String DocumentoUsuario;

    public OpcionesCliente(String DocumentoUsuario) {
        this.DocumentoUsuario = DocumentoUsuario;
        initComponents();
        
        List<Usuario> listaUsuarios = Usuario.getListaUsuarios();
        for(Usuario cadaUsuario : listaUsuarios){
            if(cadaUsuario.getDocumentoIdentificacion().equals(DocumentoUsuario)){
                jLabel1.setText("Bienvenido " + cadaUsuario.getNombre() + " " + cadaUsuario.getApellido());
                }
            }
    }
    
    public OpcionesCliente() {
        initComponents();
        List<Usuario> listaUsuarios = Usuario.getListaUsuarios();
        
        for(Usuario cadaUsuario : listaUsuarios){
            if(cadaUsuario.getDocumentoIdentificacion().equals(DocumentoUsuario)){
                jLabel1.setText("Bienvenido " + cadaUsuario.getNombre() + " " + cadaUsuario.getApellido());
                }
            }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        BuscaHabitacion = new javax.swing.JButton();
        HistorialReservas = new javax.swing.JButton();
        Salir = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        jLabel1.setText("Opciones del Usuario");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(14, 6, 280, 38));

        BuscaHabitacion.setBackground(new java.awt.Color(0, 0, 102));
        BuscaHabitacion.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        BuscaHabitacion.setForeground(new java.awt.Color(255, 255, 255));
        BuscaHabitacion.setText("Buscar Habitación");
        BuscaHabitacion.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        BuscaHabitacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscaHabitacionActionPerformed(evt);
            }
        });
        getContentPane().add(BuscaHabitacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 210, -1));

        HistorialReservas.setBackground(new java.awt.Color(0, 0, 102));
        HistorialReservas.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        HistorialReservas.setForeground(new java.awt.Color(255, 255, 255));
        HistorialReservas.setText("Historial de Reservas");
        HistorialReservas.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        HistorialReservas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HistorialReservasActionPerformed(evt);
            }
        });
        getContentPane().add(HistorialReservas, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, 210, -1));

        Salir.setBackground(new java.awt.Color(0, 0, 102));
        Salir.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        Salir.setForeground(new java.awt.Color(255, 255, 255));
        Salir.setText("Salir");
        Salir.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        getContentPane().add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 250, -1, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 410, Short.MAX_VALUE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 410, 300));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BuscaHabitacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscaHabitacionActionPerformed
        OpcionClienteHabitaciones UsHabitaciones = new OpcionClienteHabitaciones(DocumentoUsuario);
        UsHabitaciones.setSize(950, 500);
        UsHabitaciones.setResizable(false);
        UsHabitaciones.setLocationRelativeTo(null);
        UsHabitaciones.setTitle("Buscar Habitación");

                // Hacer visible la ventana
         UsHabitaciones.setVisible(true);
    }//GEN-LAST:event_BuscaHabitacionActionPerformed

    private void HistorialReservasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HistorialReservasActionPerformed
        OpcionGestionReserva UsReservas = new OpcionGestionReserva(DocumentoUsuario);
        UsReservas.setSize(700, 550);
        UsReservas.setResizable(false);
        UsReservas.setLocationRelativeTo(null);
        UsReservas.setTitle("Historial de Reservas");

                // Hacer visible la ventana
         UsReservas.setVisible(true);
    }//GEN-LAST:event_HistorialReservasActionPerformed

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
        dispose();
    }//GEN-LAST:event_SalirActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BuscaHabitacion;
    private javax.swing.JButton HistorialReservas;
    private javax.swing.JButton Salir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel2;
    // End of variables declaration//GEN-END:variables
}
