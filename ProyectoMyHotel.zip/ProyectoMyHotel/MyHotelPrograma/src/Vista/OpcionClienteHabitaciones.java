package Vista;

import Controlador.*;
import Modelo.Habitacion;
import java.time.LocalDate;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;

public class OpcionClienteHabitaciones extends javax.swing.JFrame {
    private DefaultListModel ModeloLista = new DefaultListModel();
    
    private String DocumentoUsuario;
    private int numero;
    
    //Obtenemos la fecha actual
    private LocalDate fechaActual = LocalDate.now();

    
    //Para guardar los criterios de búsqueda, ya que estos no pueden ser cambiados cuando se quiera reservar
    private ControladorHabitacion criterios = new ControladorHabitacion();
    private ControladorHabitacion reserva = new ControladorHabitacion();
    private ControladorFechas fechaEntrada;
    private ControladorFechas fechaSalida;
    private LocalDate fechaEn;
    private LocalDate fechaSal;
 
    public OpcionClienteHabitaciones(String DocumentoUsuario) {
        this.DocumentoUsuario = DocumentoUsuario;
        initComponents();
        ListaDeHabitaciones.setModel(ModeloLista);
          
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        Busqueda = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        Reserva = new javax.swing.JButton();
        Salir = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        Detalles = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        ListaDeHabitaciones = new javax.swing.JList<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();
        TipoComoda = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        Huespedes = new javax.swing.JTextField();
        info = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 381, 581, -1));

        Busqueda.setBackground(new java.awt.Color(0, 0, 102));
        Busqueda.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        Busqueda.setForeground(new java.awt.Color(255, 255, 255));
        Busqueda.setText("Buscar");
        Busqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BusquedaActionPerformed(evt);
            }
        });
        getContentPane().add(Busqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(705, 6, -1, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Reserva.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        Reserva.setText("Reservar Habitacion Seleccionada");
        Reserva.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ReservaActionPerformed(evt);
            }
        });
        jPanel2.add(Reserva, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 340, -1, -1));

        Salir.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        Salir.setText("Salir");
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        jPanel2.add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 400, -1, -1));

        jPanel5.setBackground(new java.awt.Color(0, 0, 102));

        Detalles.setBackground(new java.awt.Color(0, 0, 102));
        Detalles.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        Detalles.setForeground(new java.awt.Color(255, 255, 255));
        Detalles.setText("Ver Detalles");
        Detalles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DetallesActionPerformed(evt);
            }
        });

        ListaDeHabitaciones.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jScrollPane1.setViewportView(ListaDeHabitaciones);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(92, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(88, 88, 88))
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(173, 173, 173)
                .addComponent(Detalles)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(65, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(Detalles)
                .addGap(140, 140, 140))
        );

        jPanel2.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, -10, 450, 570));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        jLabel2.setText("Fecha de Llegada");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 50, -1, -1));

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        jLabel3.setText("Fecha de Salida");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, -1, -1));

        jLabel4.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        jLabel4.setText("Tipo de Habitacion");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 130, -1, -1));
        jPanel1.add(jDateChooser1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 50, 180, -1));
        jPanel1.add(jDateChooser2, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 90, 180, -1));

        TipoComoda.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        TipoComoda.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sencilla", "Doble", "Múltiple" }));
        TipoComoda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TipoComodaActionPerformed(evt);
            }
        });
        jPanel1.add(TipoComoda, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 130, 80, -1));

        jLabel5.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        jLabel5.setText("Número de Huéspedes");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, -1, -1));
        jPanel1.add(Huespedes, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 170, 80, -1));

        info.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        info.setText("Todas las camas y camarotes son dobles");
        jPanel1.add(info, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 200, 270, -1));

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Criterios de Búsqueda");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 0, 300, 40));

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 40, -1, -1));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, -10, 970, 560));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 370, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 560, Short.MAX_VALUE)
        );

        getContentPane().add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, -10, 370, 560));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BusquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BusquedaActionPerformed
        ModeloLista.removeAllElements();
        numero = 0;
        List<Habitacion> habitacionesDisponibles;

        //Reseteo del objeto criterios y fechas, esto pasa cada vez que se presiona el botón de búsqueda
        
        criterios = new ControladorHabitacion();
        
        //Para poder añadir los datos a la lista
        fechaEntrada = new ControladorFechas();
        fechaSalida = new ControladorFechas();

        // Obtener las fechas de los JDateChooser
        fechaEn = fechaEntrada.getFecha(jDateChooser1);
        fechaSal = fechaSalida.getFecha(jDateChooser2);
        
        //Con esto se comprueba que todos los datos estén inicialmente bien
        if((fechaEn == null) || (fechaSal == null)){
            ModeloLista.addElement("Introduzca las fechas requeridas, luego presione el botón buscar");
            return;
            
        }else{
            if(fechaEn.isBefore(fechaActual) || fechaSal.isBefore(fechaActual)){
            
                ModeloLista.addElement("La fechas deben ser mayores a la fecha actual, introduzca una nueva, luego presione el botón buscar");
                return;
        }else{
            if((fechaEn.isEqual(fechaSal)) || (fechaEn.isAfter(fechaSal))){
            ModeloLista.addElement("Parece que hay un error introduciendo las fechas, introduzcalas de nuevo y presione el botón buscar");
            return;
            }
            }
        }
        
        // Obtener el texto con el número de huéspedes
        String texto = Huespedes.getText();
        
        
        if((texto == null) || (texto.isBlank())){
            ModeloLista.addElement("Por favor ingrese un número válido y presione el botón buscar");
            return;  
        }
        
        String tipoHabitacion = (String) TipoComoda.getSelectedItem();
        
        int tipoNumero = 0;
        
        switch(tipoHabitacion){
            case "Sencilla" : tipoNumero = 2; 
            
            break;
            case "Doble" : tipoNumero = 4; 
            
            break;
            case "Múltiple" : tipoNumero = 6; 
            
            break;
        }

        numero = Integer.parseInt(texto);
        
        switch (tipoNumero) {
            case 2:
                //Para el caso de que se elija una habitación sencilla
                if((numero == 1) || (numero == 2)){
                    tipoNumero = 2;
                }else{
                    ModeloLista.addElement("El tipo de habitación y el número de huéspedes no coincide");
                    return;
                }
                break;
            case 4:
                // Para elegir una habitación doble
                if((numero == 3) || (numero == 4)){
                    tipoNumero = 4;
                }else{
                    ModeloLista.addElement("El tipo de habitación y el número de huéspedes no coincide");
                    return;
                }
                break;
            case 6:
                // Para elegir una habitación múltiple
                if((numero == 6)|| (numero == 5)){
                    tipoNumero = 6;
                }else{
                    ModeloLista.addElement("El tipo de habitación y el número de huéspedes no coincide");
                    return;}
                
                break;
        }
        
       
        //Se obtienen todas las habitaciones disponibles que cumplan con las carateristicas
        habitacionesDisponibles = criterios.mostrarLista(fechaActual, fechaEn, fechaSal, tipoNumero);
        
        if(habitacionesDisponibles.isEmpty()){
            ModeloLista.addElement("No hay habitaciones disponibles");
        }else{
            ModeloLista.addElement("  |   Número de la habitación  |  Precio Por Noche");
            
          for (Habitacion cadaHabitacion :  habitacionesDisponibles){
            ModeloLista.addElement(cadaHabitacion);
        }  
    }
        
        
        
        
    }//GEN-LAST:event_BusquedaActionPerformed

    private void DetallesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DetallesActionPerformed
        int indiceObjeto = ListaDeHabitaciones.getSelectedIndex();
        
        if (indiceObjeto != -1) {
        // Obtener el objeto seleccionado del modelo de lista
        Habitacion estaHabitacion = (Habitacion)ModeloLista.getElementAt(indiceObjeto);
     
        JOptionPane.showMessageDialog(this, estaHabitacion.detallesHabitacion());
        
        }else{
            JOptionPane.showMessageDialog(this, "No es posible mostrar detalles en este momento");
        }
    }//GEN-LAST:event_DetallesActionPerformed

    private void TipoComodaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TipoComodaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TipoComodaActionPerformed

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
        dispose();
    }//GEN-LAST:event_SalirActionPerformed

    private void ReservaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ReservaActionPerformed

        // Obtener el índice del elemento seleccionado en la lista
        int indiceObjeto = ListaDeHabitaciones.getSelectedIndex();

        // Verificar si se ha seleccionado algún elemento
        if (indiceObjeto != -1) {
            // Obtener el objeto seleccionado del modelo de lista
            Habitacion estaHabitacion = (Habitacion)ModeloLista.getElementAt(indiceObjeto);

            // Realizar alguna acción con el objeto seleccionado (por ejemplo, mostrarlo en un cuadro de diálogo)
            JOptionPane.showMessageDialog(this, "Objeto seleccionado: " + estaHabitacion + "\n Se procede a realizar la reservación con:\n Fecha actual:" + fechaActual +
                "\n Fecha Entrada : " + fechaEn + "\n FechaSalida : " + fechaSal);

            // Verificar que fechaEn y fechaSal no sean nulas
            if (fechaEn != null && fechaSal != null) {
                if(reserva.hacerReserva(estaHabitacion, DocumentoUsuario, numero, fechaEn, fechaSal, fechaActual)){
                    VentanaEmergente.mostrarVentanaEmergente("La reserva fue realizada satisfactoriamente", "Éxito", JOptionPane.INFORMATION_MESSAGE, 3000);
                } else {
                    VentanaEmergente.mostrarVentanaEmergente("Error al realizar la reserva", "Error", JOptionPane.ERROR_MESSAGE, 2000);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Las fechas de entrada y salida no están inicializadas correctamente.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione una habitación para reservar.");
        }

        jDateChooser1.setDate(null);
        jDateChooser2.setDate(null);
        Huespedes.setText("");
    }//GEN-LAST:event_ReservaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Busqueda;
    private javax.swing.JButton Detalles;
    private javax.swing.JTextField Huespedes;
    private javax.swing.JList<String> ListaDeHabitaciones;
    private javax.swing.JButton Reserva;
    private javax.swing.JButton Salir;
    private javax.swing.JComboBox<String> TipoComoda;
    private javax.swing.JLabel info;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
