package Vista;

import Controlador.ControladorHabitacion;
import Modelo.Habitacion;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class OpcionesAdmin extends javax.swing.JFrame {
    private DefaultListModel ModeloLista = new DefaultListModel();
    private DefaultListModel ModeloListaDetalles = new DefaultListModel();
    private ControladorHabitacion listaHabitaciones = new ControladorHabitacion();
    
    
    public OpcionesAdmin() {
        initComponents();
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ListaHabitaciones.setModel(ModeloLista);
        ListaDetalles.setModel(ModeloListaDetalles);
        
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        Salir = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        ListaHabitaciones = new javax.swing.JList<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        ListaDetalles = new javax.swing.JList<>();
        idHabitacion = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        CapacidadAlojo = new javax.swing.JTextField();
        Precio = new javax.swing.JTextField();
        Descripcion = new javax.swing.JTextField();
        Disponible = new javax.swing.JCheckBox();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        Detalles = new javax.swing.JButton();
        Buscar = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        Agregar = new javax.swing.JButton();
        Modificar = new javax.swing.JButton();
        Eliminar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Salir.setBackground(new java.awt.Color(0, 0, 102));
        Salir.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        Salir.setForeground(new java.awt.Color(255, 255, 255));
        Salir.setText("Salir");
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        getContentPane().add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(487, 476, -1, -1));

        jScrollPane1.setViewportBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        ListaHabitaciones.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        jScrollPane1.setViewportView(ListaHabitaciones);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(305, 95, 203, 267));

        jScrollPane3.setViewportBorder(new javax.swing.border.MatteBorder(null));

        ListaDetalles.setFont(new java.awt.Font("Yu Gothic UI", 0, 14)); // NOI18N
        jScrollPane3.setViewportView(ListaDetalles);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(526, 95, 199, 267));
        getContentPane().add(idHabitacion, new org.netbeans.lib.awtextra.AbsoluteConstraints(138, 104, 130, -1));

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Número Habitación ");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 107, 120, -1));

        jLabel3.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Capacidad de Alojo");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 147, 110, -1));

        jLabel5.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Precio por Noche");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 187, 100, -1));

        jLabel6.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Descripción");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(24, 227, 70, -1));
        getContentPane().add(CapacidadAlojo, new org.netbeans.lib.awtextra.AbsoluteConstraints(138, 144, 130, -1));
        getContentPane().add(Precio, new org.netbeans.lib.awtextra.AbsoluteConstraints(138, 184, 130, -1));
        getContentPane().add(Descripcion, new org.netbeans.lib.awtextra.AbsoluteConstraints(138, 224, 130, -1));

        Disponible.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        Disponible.setForeground(new java.awt.Color(255, 255, 255));
        Disponible.setText("Disponible");
        Disponible.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DisponibleActionPerformed(evt);
            }
        });
        getContentPane().add(Disponible, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 264, 118, -1));

        jLabel4.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        jLabel4.setText("Recuerde llenar todos lo campos antes de agregar o modificar una habitación");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(311, 374, -1, -1));

        jLabel7.setFont(new java.awt.Font("Yu Gothic UI", 0, 12)); // NOI18N
        jLabel7.setText("Cuando elimine una habitación, tenga en cuenta que puede estar reservada");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(317, 402, -1, -1));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Detalles.setBackground(new java.awt.Color(0, 0, 102));
        Detalles.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        Detalles.setForeground(new java.awt.Color(255, 255, 255));
        Detalles.setText("Ver Detalles");
        Detalles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DetallesActionPerformed(evt);
            }
        });
        jPanel2.add(Detalles, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 60, -1, -1));

        Buscar.setBackground(new java.awt.Color(0, 0, 102));
        Buscar.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        Buscar.setForeground(new java.awt.Color(255, 255, 255));
        Buscar.setText("Mostrar Habitaciones");
        Buscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BuscarActionPerformed(evt);
            }
        });
        jPanel2.add(Buscar, new org.netbeans.lib.awtextra.AbsoluteConstraints(320, 60, -1, -1));

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));
        jPanel1.setForeground(new java.awt.Color(0, 0, 102));

        Agregar.setBackground(new java.awt.Color(0, 0, 102));
        Agregar.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        Agregar.setForeground(new java.awt.Color(255, 255, 255));
        Agregar.setText("Agregar Habitación");
        Agregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AgregarActionPerformed(evt);
            }
        });

        Modificar.setBackground(new java.awt.Color(0, 0, 102));
        Modificar.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        Modificar.setForeground(new java.awt.Color(255, 255, 255));
        Modificar.setText("Modificar Habitación");
        Modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificarActionPerformed(evt);
            }
        });

        Eliminar.setBackground(new java.awt.Color(0, 0, 102));
        Eliminar.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        Eliminar.setForeground(new java.awt.Color(255, 255, 255));
        Eliminar.setText("Eliminar Habitación");
        Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Gestión de Habitaciones");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(Agregar, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Modificar, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Eliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(19, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 306, Short.MAX_VALUE)
                .addComponent(Agregar)
                .addGap(14, 14, 14)
                .addComponent(Modificar)
                .addGap(14, 14, 14)
                .addComponent(Eliminar)
                .addGap(85, 85, 85))
        );

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 290, 550));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 740, 550));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
        dispose();
    }//GEN-LAST:event_SalirActionPerformed

    private void BuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BuscarActionPerformed
        ModeloLista.removeAllElements();
        
        List<Habitacion> habitacionesDisponibles = listaHabitaciones.mostrarHabitaciones();
        
        if(habitacionesDisponibles.isEmpty()){
            ModeloLista.addElement("No hay habitaciones disponibles para mostrar");
        }else{
            ModeloLista.addElement("  |   Número de la habitación  |  Precio Por Noche");
            
          for (Habitacion cadaHabitacion :  habitacionesDisponibles){
            ModeloLista.addElement(cadaHabitacion);
        }
        }
    }//GEN-LAST:event_BuscarActionPerformed

    private void AgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AgregarActionPerformed
    
        //Obtiene el texto ingresado por el administrador 
        String IdHabitacion = idHabitacion.getText();
        String capacidadAlojo = CapacidadAlojo.getText();
        boolean isDisponible = Disponible.isSelected();
        String precioNoche = Precio.getText();
        String descripcion = Descripcion.getText();
        
        ControladorHabitacion controla = new ControladorHabitacion();
        if(controla.modificarHabitacion(IdHabitacion, capacidadAlojo, isDisponible, precioNoche, descripcion)){
            VentanaEmergente.mostrarVentanaEmergente("La habitación fue agregada satisfactoriamente", "Éxito", JOptionPane.INFORMATION_MESSAGE, 3000);
        }else{
            VentanaEmergente.mostrarVentanaEmergente("Error al agregar la habitación", "Error", JOptionPane.ERROR_MESSAGE, 2000);
        }
        
        // Limpiar los campos de la vista
        idHabitacion.setText("");
        CapacidadAlojo.setText("");
        Disponible.setSelected(false);
        Precio.setText("");
        Descripcion.setText("");
    }//GEN-LAST:event_AgregarActionPerformed

    private void ModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModificarActionPerformed

        
    //Obtiene el texto ingresado por el administrador 
    String IdHabitacion = idHabitacion.getText();
    String capacidadAlojo = CapacidadAlojo.getText();
    boolean isDisponible = Disponible.isSelected();
    String precioNoche = Precio.getText();
    String descripcion = Descripcion.getText();
     
    
    ControladorHabitacion controla = new ControladorHabitacion();
    
    

    // Obtener el índice del elemento seleccionado en la lista
    int indiceObjeto = ListaHabitaciones.getSelectedIndex();
    
    // Verificar si se ha seleccionado algún elemento
    if (indiceObjeto != -1) {
        // Obtener el objeto seleccionado del modelo de lista
        Habitacion estaHabitacion = (Habitacion)ModeloLista.getElementAt(indiceObjeto);

        //Aquí agregamos el nuevo objeto
        if(controla.modificarHabitacion(estaHabitacion.getIdHabitacion(), capacidadAlojo, isDisponible, precioNoche, descripcion)){
            VentanaEmergente.mostrarVentanaEmergente("La habitación fue modificada satisfactoriamente, presione el botón mostrar para verla", "Éxito", JOptionPane.INFORMATION_MESSAGE, 3000);
            }else{
                VentanaEmergente.mostrarVentanaEmergente("Error al modificar la habitación", "Error", JOptionPane.ERROR_MESSAGE, 2000);
        }
    }else {
        JOptionPane.showMessageDialog(this, "Por favor, seleccione una habitación de la lista.");
    }
    
    // Limpiar los campos de la vista
    idHabitacion.setText("");
    CapacidadAlojo.setText("");
    Disponible.setSelected(false);
    Precio.setText("");
    Descripcion.setText("");
    ModeloListaDetalles.removeAllElements();
    ModeloLista.removeAllElements();
    }//GEN-LAST:event_ModificarActionPerformed

    private void EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarActionPerformed
        
    ModeloListaDetalles.removeAllElements();

    // Obtener el índice del elemento seleccionado en la lista
    int indiceObjeto = ListaHabitaciones.getSelectedIndex();
    
    // Verificar si se ha seleccionado algún elemento
    if (indiceObjeto != -1) {
        // Obtener el objeto seleccionado del modelo de lista
        Habitacion estaHabitacion = (Habitacion)ModeloLista.getElementAt(indiceObjeto);

            if(estaHabitacion.eliminarHabitacion(estaHabitacion)){
                VentanaEmergente.mostrarVentanaEmergente("La habitación fue eliminada", "Éxito", JOptionPane.INFORMATION_MESSAGE, 3000);
                ModeloLista.removeElement(estaHabitacion);
            } else {
                VentanaEmergente.mostrarVentanaEmergente("Error al eliminar la habitación", "Error", JOptionPane.ERROR_MESSAGE, 2000);
            }
    } else {
        JOptionPane.showMessageDialog(this, "Por favor, seleccione una habitación de la lista para eliminar.");
    }
    }//GEN-LAST:event_EliminarActionPerformed

    private void DetallesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DetallesActionPerformed
       ModeloListaDetalles.removeAllElements();
        
        int indiceObjeto = ListaHabitaciones.getSelectedIndex();
        
        if (indiceObjeto != -1) {
        // Obtener el objeto seleccionado del modelo de lista
        Habitacion estaHabitacion = (Habitacion)ModeloLista.getElementAt(indiceObjeto);
        
            ModeloListaDetalles.addElement(estaHabitacion.detallesHabitacionAdmin());
        
        }else{
            JOptionPane.showMessageDialog(this, "No es posible mostrar detalles en este momento");
        }
    }//GEN-LAST:event_DetallesActionPerformed

    private void DisponibleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DisponibleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_DisponibleActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Agregar;
    private javax.swing.JButton Buscar;
    private javax.swing.JTextField CapacidadAlojo;
    private javax.swing.JTextField Descripcion;
    private javax.swing.JButton Detalles;
    private javax.swing.JCheckBox Disponible;
    private javax.swing.JButton Eliminar;
    private javax.swing.JList<String> ListaDetalles;
    private javax.swing.JList<String> ListaHabitaciones;
    private javax.swing.JButton Modificar;
    private javax.swing.JTextField Precio;
    private javax.swing.JButton Salir;
    private javax.swing.JTextField idHabitacion;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    // End of variables declaration//GEN-END:variables
}
