package Vista;

import javax.swing.DefaultListModel;
import Controlador.*;
import Modelo.*;
import java.time.LocalDate;
import java.util.List;
import javax.swing.JOptionPane;

public class OpcionGestionReserva extends javax.swing.JFrame {
    
    private DefaultListModel ModeloLista = new DefaultListModel();
    private String DocumentoUsuario;
    
    private ControladorFechas fechaEntrada;
    private ControladorFechas fechaSalida;
    private LocalDate fechaEn;
    private LocalDate fechaSal;
    
    //Obtenemos la fecha actual
    private LocalDate fechaActual = LocalDate.now();
    
    public OpcionGestionReserva(String DocumentoUsuario) {
        this.DocumentoUsuario = DocumentoUsuario;
        initComponents();
        ListaReservas.setModel(ModeloLista);
        jDateChooser1.setVisible(false);
        jDateChooser2.setVisible(false);
        Cantidad.setVisible(false);
        Lcant.setVisible(false);
        LfeEn.setVisible(false);
        LfeSal.setVisible(false);
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        jScrollPane1 = new javax.swing.JScrollPane();
        ListaReservas = new javax.swing.JList<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        Modificar = new javax.swing.JButton();
        Cantidad = new javax.swing.JTextField();
        Lcant = new javax.swing.JLabel();
        LfeSal = new javax.swing.JLabel();
        jDateChooser2 = new com.toedter.calendar.JDateChooser();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        LfeEn = new javax.swing.JLabel();
        Historial = new javax.swing.JButton();
        Cancelar = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        Salir = new javax.swing.JButton();

        jMenu1.setText("jMenu1");

        jMenu2.setText("jMenu2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jScrollPane1.setViewportView(ListaReservas);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(18, 37, 250, 294));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setFont(new java.awt.Font("Yu Gothic UI", 1, 12)); // NOI18N
        jLabel2.setText("Se hacen rembolsos hasta los 3 días antes de la reserva");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 450, 320, -1));

        jPanel2.setBackground(new java.awt.Color(0, 0, 102));

        Modificar.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        Modificar.setText("Modificar Reserva");
        Modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificarActionPerformed(evt);
            }
        });

        Cantidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CantidadActionPerformed(evt);
            }
        });

        Lcant.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        Lcant.setForeground(new java.awt.Color(255, 255, 255));
        Lcant.setText("Cantidad de Huéspedes");

        LfeSal.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        LfeSal.setForeground(new java.awt.Color(255, 255, 255));
        LfeSal.setText("Fecha de Salida");

        LfeEn.setFont(new java.awt.Font("Yu Gothic UI", 1, 14)); // NOI18N
        LfeEn.setForeground(new java.awt.Color(255, 255, 255));
        LfeEn.setText("Fecha de Entrada");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(Modificar, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(201, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(LfeEn)
                        .addGap(38, 38, 38)
                        .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(LfeSal)
                        .addGap(47, 47, 47)
                        .addComponent(jDateChooser2, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(Lcant)
                        .addGap(18, 18, 18)
                        .addComponent(Cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(50, 50, 50))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(Modificar, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(LfeEn))
                    .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(LfeSal))
                    .addComponent(jDateChooser2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(Lcant))
                    .addComponent(Cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(59, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(301, 35, 410, -1));

        Historial.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        Historial.setText("Ver Historial");
        Historial.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                HistorialActionPerformed(evt);
            }
        });
        jPanel1.add(Historial, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 340, -1, -1));

        Cancelar.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        Cancelar.setText("Cancelar Reserva");
        Cancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CancelarActionPerformed(evt);
            }
        });
        jPanel1.add(Cancelar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 400, -1, -1));

        jLabel1.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        jLabel1.setText("Historial de Reservas");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 258, -1));

        Salir.setFont(new java.awt.Font("Yu Gothic UI", 1, 18)); // NOI18N
        Salir.setText("Salir");
        Salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SalirActionPerformed(evt);
            }
        });
        jPanel1.add(Salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 410, -1, -1));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-10, 0, 770, 520));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SalirActionPerformed
        dispose();
    }//GEN-LAST:event_SalirActionPerformed

    private void HistorialActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_HistorialActionPerformed
        ModeloLista.removeAllElements();
        ControladorHabitacion controla = new ControladorHabitacion();
        List<Reserva> lista_usuario;
        lista_usuario = controla.mostrarReservas(DocumentoUsuario);
        
        if(!lista_usuario.isEmpty()){
            for(Reserva cadaReserva : lista_usuario){
            ModeloLista.addElement(cadaReserva);
        }
        }else{
            ModeloLista.addElement("El Usuario no tiene ninguna reserva");
        } 
    }//GEN-LAST:event_HistorialActionPerformed

    private void ModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModificarActionPerformed

    // Obtener el índice del elemento seleccionado en la lista
    int indiceObjeto = ListaReservas.getSelectedIndex();
    
    // Verificar si se ha seleccionado algún elemento
    if (indiceObjeto != -1) 
    {
        jDateChooser1.setVisible(true);
        jDateChooser2.setVisible(true);
        Cantidad.setVisible(true);
        Lcant.setVisible(true);
        LfeEn.setVisible(true);
        LfeSal.setVisible(true);
        
        String cantidad = Cantidad.getText();
        
        //Para poder añadir los datos a la lista
        fechaEntrada = new ControladorFechas();
        fechaSalida = new ControladorFechas();
        
        // Obtener las fechas de los JDateChooser
        fechaEn = fechaEntrada.getFecha(jDateChooser1);
        fechaSal = fechaSalida.getFecha(jDateChooser2);
        
        //Con esto se comprueba que todos los datos estén inicialmente bien
        if((fechaEn == null) || (fechaSal == null)){
            ModeloLista.addElement("Introduzca las fechas requeridas");
            ModeloLista.addElement("Y presione el botón de ver Historial");
            return;
            
        }else{
            if(fechaEn.isBefore(fechaActual) || fechaSal.isBefore(fechaActual)){
            
                ModeloLista.addElement("La fechas deben ser mayores a la fecha actual, introduzca una nueva");
                ModeloLista.addElement("Y presione el botón de ver Historial");
                return;
        }else{
            if((fechaEn.isEqual(fechaSal)) || (fechaEn.isAfter(fechaSal))){
            ModeloLista.addElement("Parece que hay un error introduciendo las fechas, introduzcalas de nuevo");
            ModeloLista.addElement("Y presione el botón de ver Historial");
            return;
            }
            }
        }
        
        // Convertir cantidad a int
        int cantidadInt;
        try {
            cantidadInt = Integer.parseInt(cantidad);
        } catch (NumberFormatException e) {
            VentanaEmergente.mostrarVentanaEmergente("Cantidad de Huéspedes no es un número válido", "Error", JOptionPane.ERROR_MESSAGE, 2000);
            Cantidad.setText("");
            return;
        }

        ControladorHabitacion controla = new ControladorHabitacion();
        if(controla.modificaReserva(DocumentoUsuario, cantidadInt, fechaEn, fechaSal)){  //Esto para obtener el id del Titular directamente
            VentanaEmergente.mostrarVentanaEmergente("La reserva se ha modificado satisfactoriamente", "Modificacion Válida", JOptionPane.INFORMATION_MESSAGE, 2000);
        }else{
            VentanaEmergente.mostrarVentanaEmergente("No se ha podido modificar la reserva", "Error", JOptionPane.ERROR_MESSAGE, 2000);
        }
        jDateChooser1.setDate(null);
        jDateChooser2.setDate(null);
        Cantidad.setText("");
        ModeloLista.removeAllElements();    
        
        
    }else {
        VentanaEmergente.mostrarVentanaEmergente("No hay nada que modificar", "Error", JOptionPane.ERROR_MESSAGE, 2000);
            
        }
        jDateChooser1.setVisible(false);
        jDateChooser2.setVisible(false);
        Cantidad.setVisible(false);
        Lcant.setVisible(false);
        LfeEn.setVisible(false);
        LfeSal.setVisible(false);
        
    }//GEN-LAST:event_ModificarActionPerformed

    private void CantidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CantidadActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CantidadActionPerformed

    private void CancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CancelarActionPerformed

    ControladorHabitacion controla = new ControladorHabitacion();

    // Obtener el índice del elemento seleccionado en la lista
    int indiceObjeto = ListaReservas.getSelectedIndex();
    
    // Verificar si se ha seleccionado algún elemento
    if (indiceObjeto != -1) 
    {
        
        // Obtener el objeto seleccionado del modelo de lista
        Reserva estaReserva = (Reserva)ModeloLista.getElementAt(indiceObjeto);

        if(controla.cancelarReserva(DocumentoUsuario, fechaActual, estaReserva.getIdHabitacion())){
            JOptionPane.showMessageDialog(null, "Se le hará un reembolso", "Reembolso", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Se le hará un reembolso", "Reembolso", JOptionPane.INFORMATION_MESSAGE);   
        }
    } else {
        VentanaEmergente.mostrarVentanaEmergente("Error al cancelar la reserva", "Error", JOptionPane.ERROR_MESSAGE, 2000);
            
        }
    ModeloLista.removeAllElements();    
    }//GEN-LAST:event_CancelarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Cancelar;
    private javax.swing.JTextField Cantidad;
    private javax.swing.JButton Historial;
    private javax.swing.JLabel Lcant;
    private javax.swing.JLabel LfeEn;
    private javax.swing.JLabel LfeSal;
    private javax.swing.JList<String> ListaReservas;
    private javax.swing.JButton Modificar;
    private javax.swing.JButton Salir;
    private com.toedter.calendar.JDateChooser jDateChooser1;
    private com.toedter.calendar.JDateChooser jDateChooser2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
