
package Vista;

import Controlador.ControladorUsuario;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class VentanaPrincipal extends javax.swing.JFrame {

    public VentanaPrincipal() {
        initComponents();
        setResizable(false);
        setTitle("Bienvenido a MyHotel");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel2 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        iniciarsesion = new javax.swing.JButton();
        registrarse = new javax.swing.JButton();
        salir = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ventanaPrincipal.jpg"))); // NOI18N
        jLabel2.setText("jLabel2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 0, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Yu Gothic", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("      MyHotel");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 30, 280, 70));

        iniciarsesion.setBackground(new java.awt.Color(0, 0, 102));
        iniciarsesion.setFont(new java.awt.Font("Yu Gothic", 1, 18)); // NOI18N
        iniciarsesion.setForeground(new java.awt.Color(255, 255, 255));
        iniciarsesion.setText("Iniciar Sesión");
        iniciarsesion.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        iniciarsesion.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        iniciarsesion.setMargin(new java.awt.Insets(2, 14, 2, 14));
        iniciarsesion.setMaximumSize(new java.awt.Dimension(50, 50));
        iniciarsesion.setMinimumSize(new java.awt.Dimension(50, 50));
        iniciarsesion.setPreferredSize(new java.awt.Dimension(50, 50));
        iniciarsesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iniciarsesionActionPerformed(evt);
            }
        });
        jPanel1.add(iniciarsesion, new org.netbeans.lib.awtextra.AbsoluteConstraints(351, 110, 173, 50));

        registrarse.setBackground(new java.awt.Color(0, 0, 102));
        registrarse.setFont(new java.awt.Font("Yu Gothic", 1, 18)); // NOI18N
        registrarse.setForeground(new java.awt.Color(255, 255, 255));
        registrarse.setText("Registrarse");
        registrarse.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        registrarse.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        registrarse.setMaximumSize(new java.awt.Dimension(50, 50));
        registrarse.setMinimumSize(new java.awt.Dimension(50, 50));
        registrarse.setPreferredSize(new java.awt.Dimension(50, 50));
        registrarse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registrarseActionPerformed(evt);
            }
        });
        jPanel1.add(registrarse, new org.netbeans.lib.awtextra.AbsoluteConstraints(351, 182, 173, -1));

        salir.setBackground(new java.awt.Color(0, 0, 102));
        salir.setFont(new java.awt.Font("Yu Gothic", 1, 18)); // NOI18N
        salir.setForeground(new java.awt.Color(255, 255, 255));
        salir.setText("Salir");
        salir.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        salir.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        salir.setMaximumSize(new java.awt.Dimension(50, 50));
        salir.setMinimumSize(new java.awt.Dimension(50, 50));
        salir.setPreferredSize(new java.awt.Dimension(50, 50));
        salir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirActionPerformed(evt);
            }
        });
        jPanel1.add(salir, new org.netbeans.lib.awtextra.AbsoluteConstraints(351, 250, 173, 47));

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/ventanaPrincipal.jpg"))); // NOI18N
        jLabel3.setText("jLabel3");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 612, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 253, Short.MAX_VALUE)
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 570, 240));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 597, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 374, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void iniciarsesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iniciarsesionActionPerformed

        if(ControladorUsuario.llamadoLista()){
            VentanaEmergente.mostrarVentanaEmergente("No hay usuarios registrados", "Vacío", JOptionPane.INFORMATION_MESSAGE, 2000);
        }else{VentanaLog ventanalogin = new VentanaLog();
        ventanalogin.setSize(600, 400);
        ventanalogin.setLocationRelativeTo(null);
        ventanalogin.setTitle("Inicio de Sesión");
        
        // Hacer visible la ventana
        ventanalogin.setVisible(true);
        }
    }//GEN-LAST:event_iniciarsesionActionPerformed

    private void registrarseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registrarseActionPerformed
        VentanaRegistroUsuario ventanaregistro = new VentanaRegistroUsuario();
        ventanaregistro.setLocationRelativeTo(null);
        ventanaregistro.setSize(600, 400);
        ventanaregistro.setTitle("Registrarse");
        
        // Hacer visible la ventana
        ventanaregistro.setVisible(true);
    }//GEN-LAST:event_registrarseActionPerformed

    private void salirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirActionPerformed
        this.dispose();
        VentanaEmergente.mostrarVentanaEmergente("Hasta Pronto", "Adiós", JOptionPane.INFORMATION_MESSAGE, 2000);
    }//GEN-LAST:event_salirActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton iniciarsesion;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    public javax.swing.JButton registrarse;
    public javax.swing.JButton salir;
    // End of variables declaration//GEN-END:variables
}
