package proyectohotel;
import Vista.*;
import Modelo.*;
import javax.swing.JFrame;

public class ProyectoHotel {
 
    public static void main(String[] args) {
        
        //Se crea inicialmente el usuario de administrador 
        Administrador admin = new Administrador();
        
        admin.setTipoIdentificacion("Cedula");
        admin.setDocumentoIdentificacion("1088244726");
        admin.setNombre("Sofia");
        admin.setApellido("Jaramillo");
        //admin.setCorreoElectronico("sofia.jaramillo1@utp.edu.co");
        //admin.setCont("sofia");
        admin.setCorreoElectronico("sog");
        admin.setCont("123");
        admin.setCiudadResidencia("Dosquebradas");
        admin.setDireccionResidencia("Unico");
        admin.setTelefono("3129784576");
        admin.setUsuarioAdministrador(true);
        
        //Considerando que no se llama al controlador para ingresar este usuario, se hará manualmente
        Usuario ingresoU = new Usuario();
        
        if(ingresoU.registrarUsuario(admin)){
            System.out.println("Vista Administrador seleccionable");
        }else{
            System.out.println("El Administrador no fue registrado Correctamente");
        }
        
        //Se crean 6 habitaciones para tener una base en el inventario
        
        Habitacion habitacion1 = new Habitacion("2040", 4, true, 100, "2 camas, escritorio, acceso rápido a zona de piscina");
        Habitacion habitacion2 = new Habitacion("2020", 2, true, 50, "1 cama, terraza privada, acceso al jardín");
        Habitacion habitacion3 = new Habitacion("2060", 2, true, 300, "1 cama, sala de estar, vistas panorámicas");
        Habitacion habitacion4 = new Habitacion("1010", 4, true, 200, "1 cama, 2 camas individuales, balcón, vista al mar");
        Habitacion habitacion5 = new Habitacion("1060", 6, false, 250, "Dos camas y 1 camarote, área de juegos");
        Habitacion habitacion6 = new Habitacion("1040", 2, true, 150, "1 Cama, hidromasaje, servicio a la habitación");
     
        if(habitacion1.registrarHabitacion(habitacion1)){
            System.out.println("Habitacion Anadida");
        }else{
            System.out.println("Error");
        }
        
        if(habitacion2.registrarHabitacion(habitacion2)){
            System.out.println("Habitacion Anadida");
        }else{
            System.out.println("Error");
        }
        
        if(habitacion3.registrarHabitacion(habitacion3)){
            System.out.println("Habitacion Anadida");
        }else{
            System.out.println("Error");
        }
        
        if(habitacion4.registrarHabitacion(habitacion4)){
            System.out.println("Habitacion Anadida");
        }else{
            System.out.println("Error");
        }
        
        if(habitacion5.registrarHabitacion(habitacion5)){
            System.out.println("Habitacion Anadida");
        }else{
            System.out.println("Error");
        }
        
        if(habitacion6.registrarHabitacion(habitacion6)){
            System.out.println("Habitacion Anadida");
        }else{
            System.out.println("Error");
        }
        
        Usuario primeraPersona = new Usuario("CC", "1088244723", "Melissa", "Hurtado", "w.com", "A1", "Pereira", "3128564567", "sasa");
        
        if(primeraPersona.registrarUsuario(primeraPersona)){
            System.out.println("Usuario Anadido");
        }else{
            System.out.println("Error");
        }
        
        
        // -------------------------------------------------------------------------------------------------
        // HASTA AQUÍ LLEGA LA INSERCIÓN MANUAL DE OBJETOS
         // -------------------------------------------------------------------------------------------------
        
        VentanaPrincipal ventana = new VentanaPrincipal();
        
        ventana.setSize(570, 370);
        ventana.setLocationRelativeTo(null);
        // Configurar la operación por defecto al cerrar la ventana
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Hacer visible la ventana
        ventana.setVisible(true);    
    }
    
}
