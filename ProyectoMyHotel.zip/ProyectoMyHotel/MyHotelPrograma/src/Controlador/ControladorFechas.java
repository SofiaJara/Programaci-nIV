package Controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import com.toedter.calendar.JDateChooser;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class ControladorFechas implements ActionListener{

    public LocalDate getFecha(JDateChooser fechaSeleccionada) {
        if (fechaSeleccionada.getDate() != null) {
            Date date = fechaSeleccionada.getDate();
            return date.toInstant()
                       .atZone(ZoneId.systemDefault())
                       .toLocalDate();
        }
        return null;
    }     
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
}
