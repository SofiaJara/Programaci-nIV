
package Controlador;
import Modelo.Usuario;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;


public class ControladorUsuario implements ActionListener {
    
    public boolean registrarUsuarioControlador(String TipoIdentificacion, String NumIdentificacion, String Nombres, String Apellidos, String CorreoElectronico, String Direccion, String Telefono, String Contrasena, String Ciudad) {
    
    // Comprueba que no haya campos vacíos o nulos
    if (TipoIdentificacion == null || TipoIdentificacion.isBlank() || 
        NumIdentificacion == null || NumIdentificacion.isBlank() || 
        Nombres == null || Nombres.isBlank() || 
        Apellidos == null || Apellidos.isBlank() || 
        CorreoElectronico == null || CorreoElectronico.isBlank() || 
        Direccion == null || Direccion.isBlank() || 
        Telefono == null || Telefono.isBlank() || 
        Contrasena == null || Contrasena.isBlank() || 
        Ciudad == null || Ciudad.isBlank()) 
    {
        
        JOptionPane.showMessageDialog(null, "No se aceptan campos vacíos", "ERROR", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    Usuario nuevoUsuario = new Usuario();
    
    // Copiar los datos del usuario en el nuevo objeto
    nuevoUsuario.setTipoIdentificacion(TipoIdentificacion);
    nuevoUsuario.setDocumentoIdentificacion(NumIdentificacion);
    nuevoUsuario.setNombre(Nombres);
    nuevoUsuario.setApellido(Apellidos);
    nuevoUsuario.setCorreoElectronico(CorreoElectronico);
    nuevoUsuario.setDireccionResidencia(Direccion);
    nuevoUsuario.setTelefono(Telefono);
    nuevoUsuario.setCont(Contrasena);
    nuevoUsuario.setCiudadResidencia(Ciudad);
    
    // Guarda el nuevo usuario
    if (nuevoUsuario.registrarUsuario(nuevoUsuario)){
        System.out.println("Usuario guardado correctamente");
        nuevoUsuario.mostrar();
        return true;
    } else {
        System.out.println("Error al guardar usuario");
        return false;
    }
}

    
    public boolean[] iniciarSesionControlador(String CorreoElectronico, String Contrasena){
        if (CorreoElectronico == null || CorreoElectronico.isBlank() || 
            Contrasena == null || Contrasena.isBlank()) 
    {
        boolean[] resultados = new boolean[2];
        resultados[0] = false;
        resultados[1] = false;
        return resultados;
    }
        
        return Usuario.iniciarSesionUsuario(CorreoElectronico, Contrasena);
    }
    
    public static boolean llamadoLista(){
        return Usuario.estadoLista();
    }
    
    public String obtenerCliente(String correoUsuario){
        List<Usuario> listaUsuarios = Usuario.getListaUsuarios();
        String idUsuario = null;
        
        for(Usuario cadaUsuario : listaUsuarios){
            if(cadaUsuario.getCorreoElectronico().equals(correoUsuario)){
                idUsuario = cadaUsuario.getDocumentoIdentificacion();
                }
            }
        return idUsuario;
    }
    
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
