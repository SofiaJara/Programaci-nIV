package Controlador;

import Modelo.*;
import Vista.VentanaEmergente;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

public class ControladorHabitacion implements ActionListener{
 
    //Manejo de habitaciones
    
    public List<Habitacion> mostrarLista(LocalDate fechaActual, LocalDate fechaEntrada, LocalDate fechaSalida, int tipo_habitacion) {

        List<Habitacion> habitacionBajoCriterio = new ArrayList();
        List<Habitacion> TodasLashabitaciones = Habitacion.getRegistro_habitaciones();
        
        for(Habitacion cadaHabitacion : TodasLashabitaciones){
            if(cadaHabitacion.isDisponible()){ //Comprueba que esté disponible
                System.out.println("Habita" + cadaHabitacion.getCapacidadDeAlojo() + "tipo"+ tipo_habitacion);
                if(cadaHabitacion.getCapacidadDeAlojo() == tipo_habitacion){ //Comprueba que hayan habitaciones con esa capacidad
                    if(cadaHabitacion.IsReservada(cadaHabitacion.getIdHabitacion(), fechaEntrada, fechaSalida)){ //Finalemente comprueba que no esté reservada la habitación para esa fecha
                        habitacionBajoCriterio.add(cadaHabitacion);
                    }
                }
            }    
        }
        
        return habitacionBajoCriterio;
    }
    
    public List<Habitacion> mostrarHabitaciones(){
        List<Habitacion> lista_admin = Habitacion.getRegistro_habitaciones();
        return lista_admin;
    }
    
    public boolean modificarHabitacion(String IdHabitacion, String capacidadAlojo, boolean isDisponible, String precioNoche, String descripcion){
        // Comprueba que no haya campos vacíos o nulos
    if (IdHabitacion == null || IdHabitacion.isBlank() && 
        capacidadAlojo == null || capacidadAlojo.isBlank() &&   
        precioNoche == null || precioNoche.isBlank() &&  
        descripcion == null || descripcion.isBlank()) 
    {
        JOptionPane.showMessageDialog(null, "No hay nada que modificar", "ERROR", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    
    // Convertir capacidadAlojo a int
        int capacidadAlojoInt;
        try {
            capacidadAlojoInt = Integer.parseInt(capacidadAlojo);
        } catch (NumberFormatException e) {
            VentanaEmergente.mostrarVentanaEmergente("Capacidad de alojo no es un número válido", "Error", JOptionPane.ERROR_MESSAGE, 2000);
            return false;
        }

        // Convertir precioNoche a float
        float precioNocheFlo;
        try {
            precioNocheFlo = Float.parseFloat(precioNoche);
        } catch (NumberFormatException e) {
            VentanaEmergente.mostrarVentanaEmergente("Precio por noche no es un número válido", "Error", JOptionPane.ERROR_MESSAGE, 2000);
            return false;
        }
        
        List<Habitacion> TodasLashabitaciones = Habitacion.getRegistro_habitaciones();
        
        for(Habitacion cadaHabitacion : TodasLashabitaciones){
            if(IdHabitacion.equals(cadaHabitacion.getIdHabitacion())){
                
                //Aquí se comprueba que existan elementos para modificar
                if(capacidadAlojoInt != 0){
                    cadaHabitacion.setCapacidadDeAlojo(capacidadAlojoInt);
                }
                
                if(isDisponible){
                    cadaHabitacion.setDisponible(isDisponible);
                }
                
                if(precioNocheFlo != 0){
                    cadaHabitacion.setPrecioPorNoche(precioNocheFlo);
                }   
                
                if(!descripcion.isBlank()){
                    cadaHabitacion.setDescripcion(descripcion);
                }
                
                return true;
            }
        }
        return false;
    }

    
    //Manejo de reservas

    public boolean hacerReserva(Habitacion habitacionReserva, String DocumentoUsuario, int numero, LocalDate fechaEntrada, LocalDate fechaSalida, LocalDate fechaActual){
        List<Usuario> listaUsuarios = Usuario.getListaUsuarios();
        
        for(Usuario cadaUsuario : listaUsuarios){
            if(cadaUsuario.getDocumentoIdentificacion().equals(DocumentoUsuario)){
                Reserva nuevaReserva = new Reserva();
                nuevaReserva.setCodigoReserva(); //Código
                nuevaReserva.setIdTitular(cadaUsuario.getDocumentoIdentificacion()); //Documento del usuario
                nuevaReserva.setNombreTitular(cadaUsuario.getNombre()); //Nombre del usuario
                nuevaReserva.setIdHabitacion(habitacionReserva.getIdHabitacion()); //Número de habitación
                nuevaReserva.setNumeroDeHuespedes(numero); //Número de Huéspedes
                nuevaReserva.setFechaReserva(fechaActual); //Fecha de cuando se hizo la reserva
                nuevaReserva.setEstadoReserva("Activo"); //Estado
                nuevaReserva.setFechaEntrada(fechaEntrada); //Fecha de entrada
                nuevaReserva.setFechaSalida(fechaSalida); //Fecha de salida
                
                return habitacionReserva.agregarReserva(nuevaReserva);
                }
            }
        return false;
    }
    
    public List<Reserva> mostrarReservas(String idUsuario){
        
        //Aquí obtengo todas las habitaciones
        List<Habitacion> TodasLashabitaciones = Habitacion.getRegistro_habitaciones();
        
        //Creo una lista para devolver la lista del Usuario en específico
        List<Reserva> listaReservaUsuario = new ArrayList();
        
        //Primero recorro todas las habitaciones y obtengo sus listas
        for(Habitacion cadaHabitacion : TodasLashabitaciones){
            if(!cadaHabitacion.getReservas().isEmpty()){ 
                List<Reserva> listaReservas = cadaHabitacion.getReservas();
                
                    for(Reserva cadaReserva: listaReservas){
                        System.out.println("Revisando reserva con idTitular: " + cadaReserva.getIdTitular() + "\n "  + idUsuario);
                        
                        if(cadaReserva.getIdTitular().equals(idUsuario)){
                            listaReservaUsuario.add(cadaReserva);
                            System.out.println("Reserva añadida para idUsuario: " + idUsuario);
                        }
                    }
            }
        }
        
        return listaReservaUsuario;
    }
    
    
    public boolean cancelarReserva(String idUsuario, LocalDate fechaActual, String idHabitacion){
        
        int diasDiferencia;
        
        //Aquí obtengo todas las habitaciones
        List<Habitacion> TodasLashabitaciones = Habitacion.getRegistro_habitaciones();

        //Primero recorro todas las habitaciones y obtengo sus listas
        for(Habitacion cadaHabitacion : TodasLashabitaciones){
            if(!cadaHabitacion.getReservas().isEmpty()){
                List<Reserva> listaReservas = cadaHabitacion.getReservas();
                
                    for(Reserva cadaReserva: listaReservas){
   
                        if(cadaReserva.getIdTitular().equals(idUsuario) && cadaReserva.getIdHabitacion().equals(idHabitacion)){
                        cadaReserva.setEstadoReserva("Cancelado");
                        //Se calcula si han pasado los tres días que es plazo establecido para los reembolsos
                        diasDiferencia= (int) ChronoUnit.DAYS.between(cadaReserva.getFechaEntrada(), fechaActual);
                        if(diasDiferencia > 3){
                            return true;
                            }
                        }   
                    }
            }
        }
        return false;
    }
    
    public boolean modificaReserva(String idUsuario, int cantidadNueva, LocalDate fechaEn, LocalDate fechaSal){
        //Aquí obtengo todas las habitaciones
        List<Habitacion> TodasLashabitaciones = Habitacion.getRegistro_habitaciones();
        
        //Primero recorro todas las habitaciones y obtengo sus listas
        for(Habitacion cadaHabitacion : TodasLashabitaciones){
            if(!cadaHabitacion.getReservas().isEmpty()){ 
                List<Reserva> listaReservas = cadaHabitacion.getReservas();
                
                    for(Reserva cadaReserva: listaReservas){

                     if(idUsuario.equals(cadaReserva.getIdTitular())){
                         if(cantidadNueva <= cadaReserva.getNumeroDeHuespedes()){
                             if(cadaHabitacion.IsReservada(cadaReserva.getIdHabitacion(), fechaEn, fechaSal)){
                                cadaReserva.setNumeroDeHuespedes(cantidadNueva);
                                cadaReserva.setFechaEntrada(fechaEn);
                                cadaReserva.setFechaSalida(fechaSal);
                                return true;
                             }
                         }
                     }   
                    }
            }
        }
        return false;
    }   

    @Override
    public void actionPerformed(ActionEvent e) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
